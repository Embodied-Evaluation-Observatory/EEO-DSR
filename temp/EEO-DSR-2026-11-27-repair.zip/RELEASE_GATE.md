# Release gate

Written because V0.2 was tagged before a release record existed, and because its dedup "gate" could
not fail. The gate exists so a tag carries a file, not a claim.

## Rule

No version is tagged and no package is published until `tools/release_preflight.py` exits zero and
writes `releases/<version>/preflight.json` next to the frozen manifest. A gate record is a file,
not a claim.

## Order

1. `python3 tools/freeze_release.py --version v0.5 --tag v0.5`
   Writes `releases/v0.5/manifest.json`, hashing every tracked file except `releases/` and
   `SHA256SUMS`. It refuses to overwrite an existing release directory.
2. `python3 tools/release_preflight.py --version v0.5`
   Recomputes every manifest hash and size, checks `SHA256SUMS`, runs the validator self-test,
   the full example/schema check set, and the cosine smoke test. Writes
   `releases/v0.5/preflight.json`; refuses to overwrite an existing record.
3. Commit the manifest and the gate record. Confirm `main` carries what you think it carries.
4. Create the annotated tag (`git tag -a v0.5 -m ...`).
5. Push `main`, then the tag. Do not push any other tag from a bundle.
6. Read back what the remote serves: `git ls-remote` for `main`, the tag object and its peeled
   commit. Compare the tag's tree with the local tree.
7. Publish the package and `SHA256SUMS` only after the read-back matches.

## Tag immutability

- A release tag is annotated and points at one commit forever. It is never moved, deleted, or
  force-pushed.
- A correction is a new version and a new tag. The earlier tag stays citable; its files are not
  rewritten.
- Enforce on the remote with a tag ruleset: target `v*`, restrict updates, restrict deletions, block force pushes.
  This is separate from branch protection on `main`. If the ruleset is absent, the policy still
  binds the maintainer, but the remote does not enforce it.
- Never rewrite a commit to add a signature or fix metadata. `SIGNING.md` in the Archive records
  the same rule: losing a key or missing a signature is a new release, not a history rewrite.

## Readout labels are not release gates

The preflight gate above protects the published bytes of a version. It does not decide whether a
readout may be issued. For readouts, G1-G3 are labeling obligations: a reading may be issued before
all residuals close, but only with the labels in `GOVERNANCE-ADDENDUM.md`.

- G1 residuals do not block. Print the axis definition and the fact that the 564 semantic dedup is unreproduced; never present 2,207 or 2,220 as the paper's scene count.
- G2 does not block the interval. Print nominal level, measured coverage, simulation count, size-table source, and interval method. Do not claim a nominal level that has not been calibrated. Split G2 into two objects: a coverage-grid research note (not a corpus record) and a corpus rho/n_eff interval carrying `interval_calibration: measured_below_nominal` and `nominal_95_claim: not_permitted`. The research note must print the size table and simulator design; the interval must print its own measured coverage and calibrator hash.
- G3 residuals do not block. Every count carries its row universe; differences between universes are labeled as such, not subtracted silently.

A generic disclaimer is not a label. Missing coverage, simulation count, size-table source, or
interval method means the reading is unlabeled and is not issued. Tagging a version still requires
the preflight record; this section only governs claims.

## What the checks mean

| Check | Blocks when |
|---|---|
| manifest | a tracked file differs from its recorded sha256 or size, or is missing |
| checksums | `SHA256SUMS` cannot be verified, or omits a tracked file outside `releases/` |
| self-test | `validate_record.py --self-test` is not all-pass |
| examples | any record example, observation example, or JSON Schema cross-check fails |
| smoke | the cosine helper does not run at the declared W |
| gate record | a preflight record already exists, or is written while a check is `BLOCK` |

## Limits

The gate checks that the published bytes match the frozen manifest and that the code still runs.
It does not establish that the method is statistically sound, does not replace a reader re-running
the tooling, and does not create a dedup calibration that does not exist. `calibration_status` stays
`not_established` until a real detector and its hard-negative fixture exist.
